import subprocess
import app, paramiko
import healthcheck
import logging


def get_interface(ip):
    # Set the hostname, username, and password for the device
    hostname = ip
    username = "admin"
    password = "admin"
    try:
        # Establish an SSH connection
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh_client.connect(hostname, username=username, password=password, timeout=5)

        # Send the command and receive the output
        command = "show ip interface brief"  # or "show ipv6 route" for IPv6
        stdin, stdout, stderr = ssh_client.exec_command(command)
        router_interfaces = stdout.read().decode()
        # Close the SSH connection
        ssh_client.close()
    except:
        logging.error(f"Unable to establish SSH connection to {ip}")
    return router_interfaces


def check_ping(ip_dict):
    failure_router = []
    good_router = []
    try:
        print(f"IP Dict: {ip_dict}")
        for ip in ip_dict:
            resp = healthcheck.checkPing(ip, ip_dict[ip])
            print(resp)
            if "successful" not in resp:
                logging.error(resp)
                failure_router.append(ip_dict[ip])
            else:
                logging.info(resp)
                good_router.append(ip_dict[ip])
    except subprocess.CalledProcessError:
        logging.error(f"Unable to locate IPAM.csv")

    return good_router, failure_router


def get_router_routeTable(router, ip_dict):
    for ip in ip_dict:
        if ip_dict[ip] in router:
            try:
                route = healthcheck.getRoute(ip)
                logging.info(f"Route Table for {ip_dict[ip]} \n {route} \n")
            except:
                logging.error(f"Unable to get route table for {ip_dict[ip]}")


def get_router_interface(router, ip_dict):
    for ip in ip_dict:
        if ip_dict[ip] in router:
            try:
                route = get_interface(ip)
                logging.info(f"Current Interfaces for {ip_dict[ip]} \n {route} \n")
            except:
                logging.error(f"Unable to get current interfaces for {ip_dict[ip]}")


def main():
    logging.basicConfig(
        filename="Network_Log_File.log",
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )
    # Retrieve all Routers and IPs
    ip_dict = app.read_ipam_csv("ipam.csv")

    # Function to check ping connectivity to all Routers
    reachable_routers, problematic_routers = check_ping(ip_dict)
    logging.info(f"These routers had a successful ping: {reachable_routers}")
    logging.error(f"These routers had a un-successful ping: {problematic_routers}")

    logging.info(
        "Here are the current route tables & interfaces of the reachable routers"
    )
    get_router_routeTable(reachable_routers, ip_dict)
    get_router_interface(reachable_routers, ip_dict)


if __name__ == "__main__":
    main()
