import csv
import json
# Provide the path to your CSV file
csv_file_path = "ipam.csv"

# Creating an empty dictionary to store the IP addresses with Hostnames and Interface types
ip_dict = {}

# Reading data from the CSV file and storing the IP addresses with Hostnames and Interface types in the dictionary
with open(csv_file_path, mode='r') as file:
    csv_reader = csv.DictReader(file)
    for row in csv_reader:
        hostname = row["Hostname"]
        interface_type = row["Interface_Type"]
        if hostname not in ip_dict:
            ip_dict[hostname] = {}
        if interface_type not in ip_dict[hostname]:
            ip_dict[hostname][interface_type] = {"IPv4": [], "IPv6": []}
        if "IPv4_Address" in row:
            ip_dict[hostname][interface_type]["IPv4"].append(row["IPv4_Address"])
        if "IPv6_Address" in row:
            ip_dict[hostname][interface_type]["IPv6"].append(row["IPv6_Address"])

# Printing the dictionary
print(json.dumps(ip_dict, indent=4))
