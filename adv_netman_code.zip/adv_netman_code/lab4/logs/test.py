import csv
import diffconfig

# Function to read the content of a file
def read_ipam_csv(filename):
    # Initialize an empty dictionary to store the management IPs with hostnames
    management_ips = {}
    # Open the CSV file and read it
    with open(filename, mode='r') as file:
        csv_reader = csv.DictReader(file, delimiter=',')
        for row in csv_reader:
            if row['Interface_Type'] == 'Management':
                management_ips[row['IPv4_Address']] = row['Hostname']
    return management_ips


router_dict = read_ipam_csv('ipam.csv')
diffconfig.run_diff(router_dict)